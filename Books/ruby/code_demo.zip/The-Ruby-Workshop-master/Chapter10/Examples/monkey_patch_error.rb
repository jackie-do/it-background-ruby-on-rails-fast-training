class Array 
    def size
        1/0
    end
end

my_array = ["Hello", "World"]
puts my_array.size

