class Integer
	def add_eight
		self + 8
	end
end

p 9.add_eight
