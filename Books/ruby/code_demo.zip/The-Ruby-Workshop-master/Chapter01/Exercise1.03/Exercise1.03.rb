> number_of_students.class 

 => String 
 
 > number_of_students::class 

 => String 