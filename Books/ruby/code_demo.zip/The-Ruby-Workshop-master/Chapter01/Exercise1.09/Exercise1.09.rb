var1 = "Ruby" 

 => "Ruby" 

> var2 = "Fundamentals" 

 => "Fundamentals" 

> title = var1 + ' ' + var2 

 => "Ruby Fundamentals" 
 
 > title = var1.concat(var2) 

 => "RubyFundamentals" 
 
 > title = "" 

 => "" 

> var1 = "Ruby" 

=> "Ruby" 

> title << var1 

 => "Ruby" 

 > title << " " 

 => "Ruby" 

> var2 = "Fundamentals" 

=> "Fundamentals" 

 > title << var2 

 => "RubyFundamentals" 
 
 