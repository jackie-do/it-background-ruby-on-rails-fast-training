> title = "My favorite book is Java Fundamentals" 

 => "My favorite book is Java Fundamentals" 

 

> title["Java"] = "Ruby" 

 => "Ruby" 

 

> title 

 => "My Favorite book is Ruby Fundamentals" 


 
 