print "Enter the radius for the circular candy: "
radius = gets.to_f
perimeter = 2 * 3.141592653 * radius
area = 3.141592653 * radius * radius
puts "The perimeter of the candy is #{perimeter}."
puts "The area of the candy is #{area}."
