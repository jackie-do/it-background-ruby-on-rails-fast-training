> title = "Ruby Fundamentals" 

 => "Ruby Fundamentals" 

 

> puts "My Favorite Ruby book is #{title}" 

"My Favorite Ruby book is Ruby Fundamentals" 

 => "My Favorite Ruby book is Ruby Fundamentals" 
 
 > puts "My Favorite Ruby book is #{title} and I am using it for last #{10+30} days" 

=> "My Favorite Ruby book is Ruby Fundamentals and I am using it for last 40 days" 



 
 