> number_of_students 

 => 30 

> number_of_students = "not enough for a session" 

 => "not enough for a session" 