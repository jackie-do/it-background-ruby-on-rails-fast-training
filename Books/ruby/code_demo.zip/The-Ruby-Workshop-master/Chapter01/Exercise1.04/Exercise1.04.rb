puts  "Please enter a number to added to 5" 

num = gets 

sum = 5 + num.to_i 

puts  "The result is" 

puts sum 

#run the below code on terminal
$ ruby sum.rb 

"Please enter a number to added to 5" 

10 

"The result is" 

15 