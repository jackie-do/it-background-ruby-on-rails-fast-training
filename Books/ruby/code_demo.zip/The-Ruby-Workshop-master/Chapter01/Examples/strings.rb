# encoding: us-ascii
puts "Hello".encoding

