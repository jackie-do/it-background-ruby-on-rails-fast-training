File.open('company.txt').each do |row|
  puts row
end