Dir["./models/*rb"].each { |f| require f }
