Time.class 
Time.now 
Time.now.class 
t = Time.now 
t.hour 

t.min 

t.min 
t1 = Time.now 

t2 = Time.now 
t1 + t2 
t1 + 7 
t2 - t1
