Math.class 

Math.sin(45)

Math.sqrt(144) 

x = -10 

increment = 0.25 

while(x<10) do 

y = Math.sin(x) 

puts "#{x} #{y}" 

x += increment 

end 