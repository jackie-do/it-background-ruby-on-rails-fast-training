require "byebug"

cities = ["New York", "Sydney", "London"]
cities.each do |city|
  byebug
end