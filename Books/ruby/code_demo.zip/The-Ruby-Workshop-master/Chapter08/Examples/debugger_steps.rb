def func1
  puts 'test'
end
func1
