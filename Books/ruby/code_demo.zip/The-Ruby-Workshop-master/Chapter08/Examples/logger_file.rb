require 'logger'

logger = Logger.new("log.txt")
logger.debug("User 23643 logged in")
