﻿gem install ruby-debug-ide
gem install debase (or gem install byebug)