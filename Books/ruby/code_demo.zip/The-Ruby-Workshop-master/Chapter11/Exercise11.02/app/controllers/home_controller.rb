class HomeController < ApplicationController
  def index
    @welcome_message = "Welcome to our Site"
  end
end
