class ReviewsController < ApplicationController
  def new
  end
end


class ReviewsController < ApplicationController
  def new
  end
  def create
  end
end
