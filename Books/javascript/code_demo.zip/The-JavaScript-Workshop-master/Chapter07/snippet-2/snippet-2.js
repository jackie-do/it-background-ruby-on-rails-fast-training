function callMe() {
  nowCallMe();
}

function nowCallMe() {
  callMe();
}

callMe();
