console.log("start");

setTimeout(function() {
    console.log("in setTimeout");
}, 0);

console.log("at end of code");