const message:string = "Hello, World!";
console.log(message);
