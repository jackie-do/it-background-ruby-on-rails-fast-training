let add = (a, b) => { 	// function definition
	return a + b;
}

console.log("Sum of 12 and 34 is", add(12, 34)); // Call the defined function
