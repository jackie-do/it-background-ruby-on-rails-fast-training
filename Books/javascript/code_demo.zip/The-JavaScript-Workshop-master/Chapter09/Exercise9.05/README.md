## How to use

1. Execute the script using following command :

`node http_server.js`