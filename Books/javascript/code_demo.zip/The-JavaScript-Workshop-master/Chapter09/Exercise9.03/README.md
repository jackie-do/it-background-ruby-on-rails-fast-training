## How to use

1. Execute the script using following command :

`node os.js`