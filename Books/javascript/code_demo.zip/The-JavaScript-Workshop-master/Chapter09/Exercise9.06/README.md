## How to use

1. Install dependencies.

`npm install`

2. Execute the script using following command :

`node MySQLDBConnection.js`

## Common Errors

##### Error: ER_ACCESS_DENIED_ERROR: Access denied for user 'root'@'localhost' (using password: YES)

Before running this script, make sure the mysql server must be running on local machine.