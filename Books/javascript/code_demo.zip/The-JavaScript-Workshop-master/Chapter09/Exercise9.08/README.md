## How to use

1. Install all the node packages by executing :

`npm i`

2. Run the dev server using following command :

`npm start`