for(var i = 1; i <= 5; i++){
	console.log(i);
}
for(var i = 5; i >= 1; i--){
	console.log(i);
}
for(var i = 2; i <= 10; i+=2){
	console.log(i);
}