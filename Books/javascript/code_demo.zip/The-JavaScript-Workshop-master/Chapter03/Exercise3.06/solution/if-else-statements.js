var tossValue = Math.random();
console.log("Random toss value:", tossValue);
if(tossValue >= .5){
	console.log("Heads");
}else{
	console.log("Tails");
}