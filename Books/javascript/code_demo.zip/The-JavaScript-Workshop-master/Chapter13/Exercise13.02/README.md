# Example of Object-Oriented Programming

## How to use
- Run `node humans.js`
